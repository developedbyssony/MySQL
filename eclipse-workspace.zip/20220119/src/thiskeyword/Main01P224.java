package thiskeyword;

public class Main01P224 {

	public static void main(String[] args) {
		// Person을 하나 먼저 생성해주시고, getInfo()로 조회까지 해보세요.
		Person p1 = new Person("채종훈", 20, 3000, "통계학");
		//p1.getInfo();
		
		// Person을 하나 더 생성해주시고 getInfo()로 조회까지 해보세요.
		Person p2 = new Person("김이박", 40, 5000, "수학");
		p2.getInfo();
	}

}
