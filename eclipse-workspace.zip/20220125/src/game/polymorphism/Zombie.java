package game.polymorphism;

public class Zombie extends Monster {
	public Zombie() {
		super(400,4,4,"좀비"); /// 문풀 : 부모 클래스의 생성자 파라미터에 따라 수정
	}
}
