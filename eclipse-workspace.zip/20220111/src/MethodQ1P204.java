
public class MethodQ1P204 {
	// int c, int num을 받아서
	// system.out.println(c+num);만 실행하고 종료되는
	// plus2 메서드를 정의해주신 다음
	// main 내부에서는 c에는 10, num에는 20을 달해서 실행하는
	// 코드를 작성해주시면 됩니다.
	
	public static void plus2(int c, int num) {
		System.out.println(c + num);
	}
	public static void main(String[] args) {
		plus2(10,20);
	}

}
