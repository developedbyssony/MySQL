
public class ThereeOperand01P69 {

	public static void main(String[] args) {
		// 삼항연산자는 (조건식 ? 참일때결과 : 거짓일때결과) 형식으로 작성합니다.
		// 조건식의 결과가 true라면 참일때결과에 적어적은 값이 출력되고
		// 조건식의 결과가 false라면 거짓일때결과로 적어넣은것이 출력됩니다.
		System.out.println((5 < 5 ? "참입니다" : "거짓입니다."));
		System.out.println("참입니다");
	}
}
