import java.util.Scanner;

public class ssssss {
public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println(" 이름을 입력해주세요. : ");
	String name = scan.nextLine();
	
	System.out.println("키를 입력해주세요 : ");
	double height = scan.nextDouble();
	
	System.out.println("이름 : " + name);
	System.out.println("키 : " + height);
	System.out.println("가나다" + "라마바");
}
}
