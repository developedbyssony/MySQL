package PersonClass;

public class Class {
		public String name;
		public int age;
		public String pNum;
		public String address;
		public boolean glasses;

	public void getInfo() {
		System.out.println(name);
		System.out.println(age);
		System.out.println(pNum);
		System.out.println(address);
		System.out.println(glasses);
	}
}