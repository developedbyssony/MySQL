package classs;

public class Car {

	public static void main(String[] args) {
		// 자동차의 상태(속성)를 나타내는 변수들
		public int gas; // 연료량
		public int speed; // 속도
		public String owner; // 차주
		}
}
