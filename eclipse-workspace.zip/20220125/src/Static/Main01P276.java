package Static;

public class Main01P276 {

	public static void main(String[] args) {
		StaticTest s1 = new StaticTest();
		StaticTest s2 = new StaticTest();
		StaticTest s3 = new StaticTest();

	}
}
