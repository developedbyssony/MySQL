package Structure;

public class Car {
	// 멤버변수
	// 자동차 모델, 가격, 주인
	public String model;
	public int price;
	public String owner; 
}
