package Structure;

public class Main03P204 {

	public static void main(String[] args) {
		// 웹툰 2개를 만들어서 연재 진행 및 완결까지 시켜보세요.
		// 연재 회차는 3~4회로 해주세요.
		Webtoon one = new Webtoon("작가1","웹툰2"); 
		Webtoon two = new Webtoon("작가1","웹툰2"); 

	}

}
