
public class HelloJavaP12 {

	/*
	 * 주석은 코드에 대한 설명을 덧붙이는데 사용합니다.
	 * 슬래시 2개 (//) 를 덧붙인 이후에 작성하는 내용은 그 줄만 전체 주석처리되고 
	 * 여러 줄 주석은 여닫는 부분이 함께 존재해야 합니다. 
	 */
	
    // main이라고 적힌 하단의 중괄호 열린부분 ~ 닫힌부분 사이의 코드만 실행됩니다.
	public static void main(String[] args) {
	   // sysout은 따옴표 사이에 들어온 문자를 출력합니다.
	   System.out.println("Hello World");
	}
	
}
